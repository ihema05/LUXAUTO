<?php
require_once 'db_config.php';

// Admin credentials
$admin_email = 'admin@luxuryautogallery.com';
$admin_password = 'admin123';

// Hash the password
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

// Check if admin already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update existing admin
    $stmt = $conn->prepare("UPDATE users SET password = ?, is_admin = 1 WHERE email = ?");
    $stmt->bind_param("ss", $hashed_password, $admin_email);
    
    if ($stmt->execute()) {
        echo "Admin user updated successfully!";
    } else {
        echo "Error updating admin user: " . $conn->error;
    }
} else {
    // Create new admin
    $stmt = $conn->prepare("INSERT INTO users (email, password, is_admin) VALUES (?, ?, 1)");
    $stmt->bind_param("ss", $admin_email, $hashed_password);
    
    if ($stmt->execute()) {
        echo "Admin user created successfully!";
    } else {
        echo "Error creating admin user: " . $conn->error;
    }
}

$stmt->close();
$conn->close();
?> 