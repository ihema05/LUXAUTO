<?php
require_once 'db_config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get car details if provided
$car_id = isset($_GET['car_id']) ? (int)$_GET['car_id'] : 0;
$car = null;

if ($car_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM cars WHERE id = ?");
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $car = $result->fetch_assoc();
    $stmt->close();
}

// Generate warranty number
$warranty_number = 'W' . date('Ymd') . str_pad($car_id, 4, '0', STR_PAD_LEFT);

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Get user credentials
$stmt = $conn->prepare("SELECT uc.*, u.email FROM user_credentials uc JOIN users u ON uc.user_id = u.id WHERE uc.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$credentials = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_id = $_POST['car_id'];
    $warranty_type = $_POST['warranty_type'];
    $start_date = date('Y-m-d');
    $end_date = date('Y-m-d', strtotime('+3 years')); // 3-year warranty by default

    // Check if user has provided their credentials
    if (!$credentials) {
        $error_message = "Please complete your profile information first.";
    } else {
        // Insert warranty record
        $stmt = $conn->prepare("INSERT INTO warranties (user_id, car_id, warranty_type, start_date, end_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $user_id, $car_id, $warranty_type, $start_date, $end_date);

        if ($stmt->execute()) {
            $success_message = "Warranty registration successful!";
        } else {
            $error_message = "Error registering warranty. Please try again.";
        }
    }
}

// Get user's warranties
$stmt = $conn->prepare("
    SELECT w.*, c.make, c.model, c.year 
    FROM warranties w 
    JOIN cars c ON w.car_id = c.id 
    WHERE w.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$warranties = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Warranty - Car Dealership</title>
    <link rel="stylesheet" href="CarCss.css">
    <style>
        .warranty-container {
            max-width: 800px;
            margin: 100px auto;
            padding: 40px;
            background: #fff;
            border: 2px solid #c4a484;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .warranty-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #c4a484;
        }
        .warranty-details {
            margin: 20px 0;
        }
        .warranty-details p {
            margin: 10px 0;
            font-size: 16px;
        }
        .warranty-footer {
            margin-top: 40px;
            text-align: center;
            font-style: italic;
        }
        .print-button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #c4a484;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #b39476;
        }
        @media print {
            .print-button {
                display: none;
            }
            .warranty-container {
                box-shadow: none;
                border: 1px solid #000;
            }
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-content">
            <a href="luxury-dealership.html" class="logo">LUX<span style="color: var(--accent-color)">AUTO</span></a>
            <div class="nav-links">
                <a href="luxury-dealership.php"><span>Home</span></a>
                <a href="CarDearlship.php"><span>Sales</span></a>
                <a href="CarDearlship.html"><span>Featured</span></a>
                <a href="about.html"><span>About</span></a>
                <a href="contact.html"><span>Contact</span></a>
                <a href="user_carparts.php"><span>Parts</span></a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="warranty.php" class="active"><span>Warranty</span></a>
                    <a href="user-credentials.php"><span>Profile</span></a>
                    <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                        <a href="admin_dashboard.php"><span>Admin</span></a>
                    <?php endif; ?>
                    <a href="logout.php" class="login-btn"><span>Logout</span></a>
                <?php else: ?>
                    <a href="login.php" class="login-btn"><span>Login</span></a>
                    <a href="register.php" class="register-btn"><span>Register</span></a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="warranty-container">
        <div class="warranty-header">
            <h1>Vehicle Warranty Certificate</h1>
            <p>Warranty Number: <?php echo htmlspecialchars($warranty_number); ?></p>
        </div>

        <div class="warranty-details">
            <h2>Vehicle Information</h2>
            <?php if ($car): ?>
                <p><strong>Make:</strong> <?php echo htmlspecialchars($car['make']); ?></p>
                <p><strong>Model:</strong> <?php echo htmlspecialchars($car['model']); ?></p>
                <p><strong>Year:</strong> <?php echo htmlspecialchars($car['year']); ?></p>
                <p><strong>VIN:</strong> <?php echo htmlspecialchars($warranty_number); ?></p>
            <?php endif; ?>

            <h2>Owner Information</h2>
            <?php if ($credentials): ?>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($credentials['first_name'] . ' ' . $credentials['last_name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($credentials['email']); ?></p>
                <p><strong>Purchase Date:</strong> <?php echo date('F d, Y'); ?></p>
            <?php else: ?>
                <p>Please complete your profile information first.</p>
            <?php endif; ?>
        </div>

        <div class="warranty-terms">
            <h2>Warranty Terms</h2>
            <p>This warranty covers:</p>
            <ul>
                <li>Engine and transmission for 5 years or 60,000 miles</li>
                <li>Electrical system for 3 years or 36,000 miles</li>
                <li>Air conditioning system for 2 years or 24,000 miles</li>
                <li>Paint and body work for 1 year or 12,000 miles</li>
            </ul>
        </div>

        <div class="warranty-footer">
            <p>This warranty is valid from the date of purchase and is non-transferable.</p>
            <p>For warranty claims, please contact our service department at +20 1026085267</p>
        </div>

        <button class="print-button" onclick="window.print()">Print Warranty</button>
    </div>
</body>
</html> 