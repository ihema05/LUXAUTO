<?php
require_once 'db_config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$item_id = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;
$item_type = isset($_GET['type']) ? $_GET['type'] : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_number = $_POST['card_number'];
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];
    $card_holder = $_POST['card_holder'];
    
    // Insert purchase record
    $stmt = $conn->prepare("INSERT INTO purchases (user_id, item_type, item_id, status) VALUES (?, ?, ?, 'completed')");
    $stmt->bind_param("isi", $user_id, $item_type, $item_id);
    
    if ($stmt->execute()) {
        // Redirect to warranty page
        header("Location: warranty.php?car_id=" . $item_id);
        exit();
    } else {
        $error_message = "Error processing payment. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Purchase - LUXAUTO</title>
    <link rel="stylesheet" href="CarCss.css">
    <style>
        .purchase-container {
            max-width: 600px;
            margin: 100px auto;
            padding: 40px;
            background: #fff;
            border: 2px solid #c4a484;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .purchase-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .form-group label {
            font-weight: bold;
            color: #333;
        }
        .form-group input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .submit-button {
            padding: 12px 24px;
            background-color: #c4a484;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .submit-button:hover {
            background-color: #b39476;
        }
        .error-message {
            color: #dc3545;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-content">
            <a href="luxury-dealership.html" class="logo">LUX<span style="color: var(--accent-color)">AUTO</span></a>
            <div class="nav-links">
                <a href="luxury-dealership.html">Home</a>
                <a href="CarDearlship.php">Car Sales</a>
                <a href="CarDearlship.html">Featured</a>
                <a href="about.html">About</a>
                <a href="contact.html">Contact</a>
                <a href="user_carparts.php">Car Parts</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="warranty.php">Warranty</a>
                    <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                        <a href="admin_dashboard.php">Admin</a>
                    <?php endif; ?>
                    <a href="logout.php" class="login-btn">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="login-btn">Login</a>
                    <a href="register.php" class="register-btn">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="purchase-container">
        <h1>Complete Your Purchase</h1>
        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        
        <form class="purchase-form" method="POST" action="">
            <div class="form-group">
                <label for="card_holder">Card Holder Name</label>
                <input type="text" id="card_holder" name="card_holder" required>
            </div>
            
            <div class="form-group">
                <label for="card_number">Card Number</label>
                <input type="text" id="card_number" name="card_number" pattern="[0-9]{16}" maxlength="16" required>
            </div>
            
            <div class="form-group">
                <label for="expiry_date">Expiry Date (MM/YY)</label>
                <input type="text" id="expiry_date" name="expiry_date" pattern="(0[1-9]|1[0-2])\/([0-9]{2})" placeholder="MM/YY" maxlength="5" required>
            </div>
            
            <div class="form-group">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" pattern="[0-9]{3,4}" maxlength="4" required>
            </div>
            
            <button type="submit" class="submit-button">Complete Purchase</button>
        </form>
    </div>

    <script>
        // Format card number input
        document.getElementById('card_number').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });

        // Format expiry date input
        document.getElementById('expiry_date').addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.slice(0,2) + '/' + value.slice(2);
            }
            this.value = value;
        });

        // Format CVV input
        document.getElementById('cvv').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>
</body>
</html> 