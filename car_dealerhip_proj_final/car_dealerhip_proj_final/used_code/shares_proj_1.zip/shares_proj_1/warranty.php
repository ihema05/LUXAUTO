<?php
require_once 'db_config.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get car details if provided
$car_id = isset($_GET['car_id']) ? (int)$_GET['car_id'] : 0;
$car = null;

if ($car_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM cars WHERE id = ?");
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $car = $result->fetch_assoc();
    $stmt->close();
}

// Generate warranty number
$warranty_number = 'W' . date('Ymd') . str_pad($car_id, 4, '0', STR_PAD_LEFT);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Warranty - Car Dealership</title>
    <link rel="stylesheet" href="CarCss.css">
    <style>
        .warranty-container {
            max-width: 800px;
            margin: 100px auto;
            padding: 40px;
            background: #fff;
            border: 2px solid #c4a484;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .warranty-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #c4a484;
        }
        .warranty-details {
            margin: 20px 0;
        }
        .warranty-details p {
            margin: 10px 0;
            font-size: 16px;
        }
        .warranty-footer {
            margin-top: 40px;
            text-align: center;
            font-style: italic;
        }
        .print-button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #c4a484;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #b39476;
        }
        @media print {
            .print-button {
                display: none;
            }
            .warranty-container {
                box-shadow: none;
                border: 1px solid #000;
            }
        }
    </style>
</head>
<body>
    <div class="warranty-container">
        <div class="warranty-header">
            <h1>Vehicle Warranty Certificate</h1>
            <p>Warranty Number: <?php echo htmlspecialchars($warranty_number); ?></p>
        </div>

        <div class="warranty-details">
            <h2>Vehicle Information</h2>
            <?php if ($car): ?>
                <p><strong>Make:</strong> <?php echo htmlspecialchars($car['make']); ?></p>
                <p><strong>Model:</strong> <?php echo htmlspecialchars($car['model']); ?></p>
                <p><strong>Year:</strong> <?php echo htmlspecialchars($car['year']); ?></p>
                <p><strong>VIN:</strong> <?php echo htmlspecialchars($warranty_number); ?></p>
            <?php endif; ?>

            <h2>Owner Information</h2>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <p><strong>Purchase Date:</strong> <?php echo date('F d, Y'); ?></p>
        </div>

        <div class="warranty-terms">
            <h2>Warranty Terms</h2>
            <p>This warranty covers:</p>
            <ul>
                <li>Engine and transmission for 5 years or 60,000 miles</li>
                <li>Electrical system for 3 years or 36,000 miles</li>
                <li>Air conditioning system for 2 years or 24,000 miles</li>
                <li>Paint and body work for 1 year or 12,000 miles</li>
            </ul>
        </div>

        <div class="warranty-footer">
            <p>This warranty is valid from the date of purchase and is non-transferable.</p>
            <p>For warranty claims, please contact our service department at +20 1026085267</p>
        </div>

        <button class="print-button" onclick="window.print()">Print Warranty</button>
    </div>
</body>
</html> 