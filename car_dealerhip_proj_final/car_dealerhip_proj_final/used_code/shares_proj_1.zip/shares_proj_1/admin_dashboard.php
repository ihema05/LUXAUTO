<?php
require_once 'db_config.php';
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

// Handle car deletion
if (isset($_POST['delete_car'])) {
    $car_id = (int)$_POST['car_id'];
    
    // Get the image URL before deleting the car
    $stmt = $conn->prepare("SELECT image_url FROM cars WHERE id = ?");
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $car = $result->fetch_assoc();
    
    // Delete the car
    $stmt = $conn->prepare("DELETE FROM cars WHERE id = ?");
    $stmt->bind_param("i", $car_id);
    
    if ($stmt->execute()) {
        // Delete the image file if it exists
        if ($car && file_exists($car['image_url'])) {
            unlink($car['image_url']);
        }
        $success = "Car deleted successfully";
    } else {
        $error = "Error deleting car";
    }
    $stmt->close();
}

// Handle adding new car
if (isset($_POST['add_car'])) {
    $make = filter_var($_POST['make'], FILTER_SANITIZE_STRING);
    $model = filter_var($_POST['model'], FILTER_SANITIZE_STRING);
    $year = (int)$_POST['year'];
    $price = (float)$_POST['price'];
    $description = filter_var($_POST['description'], FILTER_SANITIZE_STRING);
    $image_url = '';
    
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        $file_extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $new_filename = uniqid() . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;
        
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image_url = $target_file;
        } else {
            $error = "Error uploading image";
        }
    }
    
    if (empty($error)) {
        $stmt = $conn->prepare("INSERT INTO cars (make, model, year, price, description, image_url) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssidss", $make, $model, $year, $price, $description, $image_url);
        
        if ($stmt->execute()) {
            $success = "Car added successfully";
        } else {
            $error = "Error adding car";
        }
        $stmt->close();
    }
}

// Fetch all cars
$cars = $conn->query("SELECT * FROM cars ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Car Dealership</title>
    <link rel="stylesheet" href="CarCss.css">
    <style>
        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .admin-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .car-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .car-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .car-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .car-info {
            padding: 15px;
        }
        .delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }
        .delete-btn:hover {
            background: #c82333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .success {
            color: #28a745;
            background: #d4edda;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .submit-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .submit-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Admin Dashboard</h1>
        
        <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        
        <div class="admin-section">
            <h2>Add New Car</h2>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group">
                        <label for="make">Brand:</label>
                        <input type="text" id="make" name="make" required placeholder="e.g., Toyota, BMW">
                    </div>
                    
                    <div class="form-group">
                        <label for="model">Model:</label>
                        <input type="text" id="model" name="model" required placeholder="e.g., Camry, X5">
                    </div>
                    
                    <div class="form-group">
                        <label for="year">Year:</label>
                        <input type="number" id="year" name="year" required min="1900" max="<?php echo date('Y') + 1; ?>" placeholder="e.g., 2024">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="price">Price ($):</label>
                        <input type="number" id="price" name="price" step="0.01" required min="0" placeholder="e.g., 25000">
                    </div>
                    
                    <div class="form-group">
                        <label for="image">Image:</label>
                        <input type="file" id="image" name="image" accept="image/*" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" required rows="4" placeholder="Enter car description..."></textarea>
                </div>
                
                <button type="submit" name="add_car" class="submit-btn">Add Car</button>
            </form>
        </div>
        
        <div class="admin-section">
            <h2>Manage Cars</h2>
            <div class="car-grid">
                <?php while ($car = $cars->fetch_assoc()): ?>
                    <div class="car-card">
                        <img src="<?php echo htmlspecialchars($car['image_url']); ?>" alt="<?php echo htmlspecialchars($car['make'] . ' ' . $car['model']); ?>">
                        <div class="car-info">
                            <h3><?php echo htmlspecialchars($car['make'] . ' ' . $car['model'] . ' (' . $car['year'] . ')'); ?></h3>
                            <p><?php echo htmlspecialchars($car['description']); ?></p>
                            <p><strong>Price: $<?php echo number_format($car['price'], 2); ?></strong></p>
                            <form method="POST" action="" onsubmit="return confirm('Are you sure you want to delete this car?');">
                                <input type="hidden" name="car_id" value="<?php echo $car['id']; ?>">
                                <button type="submit" name="delete_car" class="delete-btn">Delete Car</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</body>
</html> 