<?php
require_once 'db_config.php';
session_start();

// Fetch all cars from database
$cars = $conn->query("SELECT * FROM cars ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luxury Auto Gallery - Collection</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="CarCss.css">
    <style>
        .car-details-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.8);
            z-index: 1000;
        }
        .modal-content {
            position: relative;
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            width: 80%;
            max-width: 800px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
        }
        .close-modal {
            position: absolute;
            right: 20px;
            top: 10px;
            font-size: 24px;
            cursor: pointer;
            color: #666;
        }
        .car-details {
            display: flex;
            gap: 30px;
            margin-top: 20px;
        }
        .car-image {
            flex: 1;
            max-width: 50%;
        }
        .car-image img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }
        .car-info {
            flex: 1;
        }
        .car-info h2 {
            color: var(--primary-color);
            margin-bottom: 15px;
        }
        .car-info p {
            margin: 10px 0;
            font-size: 16px;
        }
        .price {
            color: var(--secondary-color);
            font-size: 24px;
            font-weight: bold;
            margin: 15px 0;
        }
        .warranty-btn {
            display: inline-block;
            padding: 12px 25px;
            background-color: var(--secondary-color);
            color: var(--primary-color);
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 20px;
            transition: background-color 0.3s;
        }
        .warranty-btn:hover {
            background-color: #b39476;
        }
    </style>
</head>
<body>
    <nav>
        <div class="nav-content">
            <a href="luxury-dealership.html" class="logo">LUX AUTO</a>
            <div class="nav-links">
                <a href="luxury-dealership.html">Home</a>
                <a href="CarDearlship.php">Featured</a>
                <a href="about.html">About</a>
                <a href="luxury-dealership.html#contact">Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="logout.php" class="logout-btn">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="login-btn">Login</a>
                    <a href="register.php" class="register-btn">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <section class="collection">
        <h2 class="section-title">Our Luxury Collection</h2>
        <div class="vehicles-grid">
            <?php while ($car = $cars->fetch_assoc()): ?>
                <div class="vehicle-card">
                    <div class="car-image-container" onclick="showCarDetails(<?php echo htmlspecialchars(json_encode($car)); ?>)">
                        <?php if ($car['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($car['image_url']); ?>" alt="<?php echo htmlspecialchars($car['make'] . ' ' . $car['model']); ?>" class="vehicle-image">
                        <?php endif; ?>
                        <div class="vehicle-info">
                            <h3><?php echo htmlspecialchars($car['make'] . ' ' . $car['model']); ?></h3>
                            <p class="price">$<?php echo number_format($car['price'], 2); ?></p>
                            <p><?php echo htmlspecialchars($car['description']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </section>

    <!-- Car Details Modal -->
    <div id="carDetailsModal" class="car-details-modal">
        <div class="modal-content">
            <span class="close-modal" onclick="closeCarDetails()">&times;</span>
            <div class="car-details">
                <div class="car-image">
                    <img id="modalCarImage" src="" alt="Car Image">
                </div>
                <div class="car-info">
                    <h2 id="modalCarTitle"></h2>
                    <p id="modalCarYear"></p>
                    <p id="modalCarDescription"></p>
                    <p class="price" id="modalCarPrice"></p>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="#" id="modalWarrantyBtn" class="warranty-btn">Get Warranty</a>
                    <?php else: ?>
                        <p>Please <a href="login.php">login</a> to get warranty information.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showCarDetails(car) {
            const modal = document.getElementById('carDetailsModal');
            const modalImage = document.getElementById('modalCarImage');
            const modalTitle = document.getElementById('modalCarTitle');
            const modalYear = document.getElementById('modalCarYear');
            const modalDescription = document.getElementById('modalCarDescription');
            const modalPrice = document.getElementById('modalCarPrice');
            const warrantyBtn = document.getElementById('modalWarrantyBtn');

            modalImage.src = car.image_url;
            modalImage.alt = car.make + ' ' + car.model;
            modalTitle.textContent = car.make + ' ' + car.model;
            modalYear.textContent = 'Year: ' + car.year;
            modalDescription.textContent = car.description;
            modalPrice.textContent = '$' + parseFloat(car.price).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});

            if (warrantyBtn) {
                warrantyBtn.href = 'warranty.php?car_id=' + car.id;
            }

            modal.style.display = 'block';
        }

        function closeCarDetails() {
            document.getElementById('carDetailsModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('carDetailsModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
    </script>

    <section id="contact" class="contact">
        <h2 class="section-title">Contact Us</h2>
        <div class="contact-grid">
            <div class="contact-info">
                <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="contact-info">
                <i class="fas fa-phone"></i>
                <p>+20 1026085267</p>
            </div>
            <div class="contact-info">
                <i class="fas fa-envelope"></i>
                <p>Blur243569@gmail.com</p>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 Luxury Auto Gallery. All rights reserved.</p>
    </footer>
</body>
</html> 